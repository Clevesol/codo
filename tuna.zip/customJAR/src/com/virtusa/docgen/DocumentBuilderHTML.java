package com.virtusa.docgen;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.DocumentType;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class DocumentBuilderHTML {

	private DocumentBuilderFactory dFactory;
	private DocumentBuilder dBuilder;

//	private DocumentBuilderHTML() {
//		this.initComponents();
//	}

	private void initComponents() {
		try {
			if(this.dFactory==null)
			this.dFactory = DocumentBuilderFactory.newInstance();
			if(this.dBuilder==null)
			this.dBuilder = dFactory.newDocumentBuilder();
			//this.dFactory.setValidating(false);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	
	
	{
		//initComponents();
	}
	
	
	/*
	 * @param content : html content to be modified
	 * @param tableIndex : the index of the table within the parent container
	 * @param cols[] : desired index(s) of columns to be removed
	 * 
	 * this method will ouput a modified version of the html content inputted
	 * with required fields removed
	 */
	
	public String removeColumns(String content, int tableIndex, String columns) {

		this.initComponents();

		
		String arr[] = columns.split(",");
		int[] cols = this.getIntArrayFromStringArray(arr);
		
		
		sortDesc(cols);

		try {
			BufferedInputStream bis = new BufferedInputStream(new ByteArrayInputStream(
					content.getBytes(StandardCharsets.UTF_8)));
			Document document = dBuilder.parse(bis);
			
			
			
			
			
			
			Element body = (Element) document.getElementsByTagName("body").item(0);
			NodeList tableList = body.getElementsByTagName("table");

			if (tableList.getLength() > 0 && cols.length > 0) {
				Element table = (Element) tableList.item(tableIndex);
				if (table == null)
					throw new Exception("table index invalid");
				NodeList recordList = table.getElementsByTagName("tr");
				for (int t = 0; t < recordList.getLength(); t++) {
					Element record = (Element) recordList.item(t);
					NodeList colList = record.getElementsByTagName("td");
					NodeList headList = record.getElementsByTagName("th");
					if (cols.length == colList.getLength())
						throw new Exception("no columns remained error");

					for (int v = 0; v < cols.length; v++) {
						if(colList.item(cols[v])!=null){
						record.removeChild(colList.item(cols[v]));
						}
						if(headList.item(cols[v])!=null){
							record.removeChild(headList.item(cols[v]));
						}

					}
				}
			} else {
				if (tableList.getLength() < 0)
					throw new Exception("no tables found");
			}
			
			String writer = this.getDocumentToString(document);

//			DOMSource source = new DOMSource(document);
//			TransformerFactory tFactory = TransformerFactory.newInstance();
//			Transformer transFormer = tFactory.newTransformer();
//
//			
//			
//			transFormer.setOutputProperty(OutputKeys.INDENT, "yes");
//			transFormer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
//			//transFormer.setOutputProperty(OutputKeys.METHOD, "xml");
//			
//			DOMImplementation imp = document.getImplementation();
//			DocumentType dType = imp.createDocumentType("doctype", "html", "html.doc");
//			
//			//transFormer.setOutputProperty(OutputKeys.DOCTYPE_PUBLIC, dType.getPublicId());
//			transFormer.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, dType.getSystemId());
//			
//			
//			
//			StringWriter writer = new StringWriter();
//			StreamResult result = new StreamResult(writer);
//
//			transFormer.transform(source, result);

			return writer;

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}
	
	private String getDocumentToString(Document document) throws Exception{
		
		
		DOMSource source = new DOMSource(document);
		TransformerFactory tFactory = TransformerFactory.newInstance();
		Transformer transFormer = tFactory.newTransformer();

		
		
		transFormer.setOutputProperty(OutputKeys.INDENT, "yes");
		transFormer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
		//transFormer.setOutputProperty(OutputKeys.METHOD, "xml");
		
		DOMImplementation imp = document.getImplementation();
		DocumentType dType = imp.createDocumentType("doctype", "html", "html.doc");
		
		//transFormer.setOutputProperty(OutputKeys.DOCTYPE_PUBLIC, dType.getPublicId());
		transFormer.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, dType.getSystemId());
		
		
		
		StringWriter writer = new StringWriter();
		StreamResult result = new StreamResult(writer);

		transFormer.transform(source, result);
		
		
		return writer.toString();
	}

	private void sortDesc(int[] arr) {

		Arrays.sort(arr);
		for (int t = 0; t < arr.length; t++) {
			arr[t] = arr[t] * -1;
		}

		Arrays.sort(arr);
		for (int t = 0; t < arr.length; t++) {
			arr[t] = arr[t] * -1;
		}
	}


	public String pickColumns(String content, int tableIndex, String columns) {

		this.initComponents();
		
		String arr[] = columns.split(",");
		int[] cols = this.getIntArrayFromStringArray(arr);
		
		
		//sortDesc(cols);

		
		
		try {
			BufferedInputStream bis = new BufferedInputStream(new ByteArrayInputStream(
					content.getBytes(StandardCharsets.UTF_8)));
			Document document = dBuilder.parse(bis);

			Element body = (Element) document.getElementsByTagName("body").item(0);
			NodeList tableList = body.getElementsByTagName("table");

			if (tableList.getLength() > 0 && cols.length > 0) {

				Element table = (Element) tableList.item(tableIndex);
				if (table == null) throw new Exception("table index invalid");
				NodeList recordList = table.getElementsByTagName("tr");
				
				for (int t = 0; t < recordList.getLength(); t++) {
					Element record = (Element) recordList.item(t);
					NodeList colList = record.getElementsByTagName("td");
					NodeList headList = record.getElementsByTagName("th");
					if (cols.length == colList.getLength())
						throw new Exception("no columns remained error");
					
					java.util.ArrayList<Node> nodeCols = new ArrayList<Node>();
					java.util.ArrayList<Node> nodeHeads = new ArrayList<Node>();

					for(int index : cols){
						
						nodeCols.add(colList.item(index));
						nodeHeads.add(headList.item(index));
					}
					
					

					for(int u = colList.getLength()-1; u >=0;u--){
						record.removeChild(colList.item(u));
					}
					
					for(int u = headList.getLength()-1; u>=0; u--){
						record.removeChild(headList.item(u));
					}
					
					
					
					
					for(Node n : nodeCols){
						if(n!=null)
						record.appendChild(n);
					}
					
					for(Node n : nodeHeads){
						if(n!=null)
							record.appendChild(n);
					}
					
//					for(int cc = colList.getLength()-1; cc >= 0; cc--){
//						
//						for(int bc = 0; bc <  node.size(); bc++){
//							System.out.println(node.get(bc).equals(colList.item(cc)));
//							if(node.get(bc) != colList.item(cc)){
//								record.removeChild(node.get(bc));
//							}
//						}
//						
//						for(int vv = 0; vv < cols.length; vv++){
//							if(cols[vv] == cc) continue;
//							record.removeChild(colList.item(cc-1));
//						}
//					}

//					for (int v = 0; v < cols.length; v++) {
//						if(cols[v] == v) continue;
//						record.removeChild(colList.item(cols[v]));
//
//					}
				}
				
			} else {
				if (tableList.getLength() < 0)
					throw new Exception("no tables found");
			}
			
			String writer = this.getDocumentToString(document);

//			DOMSource source = new DOMSource(document);
//			TransformerFactory tFactory = TransformerFactory.newInstance();
//			Transformer transFormer = tFactory.newTransformer();
//
//			StringWriter writer = new StringWriter();
//			StreamResult result = new StreamResult(writer);
//
//			transFormer.transform(source, result);

			return writer;

		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return null;
	}




	/*
	 * renders and outputs buffered string input in to a html file
	 * if the input string is valid in html syntax
	 * @param contentBuffer; html content that should be appended to the html
	 * document
	 * 
	 * @param path; path should be used to output the rendered document
	 */

	public void writeToFile(String conentBuffer, String path,String templateName) throws Exception {
		this.initComponents();
		
		if(path.charAt(path.length()-1) !='\\' || path.charAt(path.length()-1) != '/'){
			
			if(path.contains("/") & path.contains("\\")){
				throw new Exception("Invalid path");
			}
			
			if(path.contains("/")){
				path += "/";
			}else if(path.contains("\\")){
				path += '\\';
			}else{
				path += "/";
			}
		}
		
		path += templateName;
		File templateFile = new File(path);
		if (!templateFile.exists()) {
			templateFile.createNewFile();
		}

		FileWriter fw = new FileWriter(templateFile.getAbsolutePath());
		BufferedWriter writer = new BufferedWriter(fw);

		writer.write(conentBuffer);
		writer.flush();
		writer.close();
		System.out.println("document creation successfull");
	}
	
	
	private int[] getIntArrayFromStringArray(String[] arr){
		int r[] = new int[arr.length];
		if(arr.length > 0){
			for(int t = 0 ; t < arr.length; t++){
				String s  = arr[t];
				r[t] = Integer.parseInt(s);
			}
		}
		return r;
	}

//	public static void main(String args[]) {
//
//		DocumentBuilderHTML b = new DocumentBuilderHTML();
//		
//		try {
//
//			//String outPut = b.removeColumns("<body><table col='3'><tr><td>content 0</td><td>content 1</td><td>content 2</td></tr><tr><td>content 0</td><td>content 1</td><td>content 2</td></tr><tr><td>content 0</td><td>content 1</td><td>content 2</td></tr></table></body>",0, new int[] { 0, 2 });
//			String outPut2 = b
//					.pickColumns(
//							"<body><table col='3'><tr><th>h1</th><th>h2</th><th>h3</th></tr><tr><td>c1</td><td>c2</td><td>c3</td></tr></table></body>",
//							0, "0,2");
//			
//		//	b.createHTML(outPut, "test.html");
//			b.writeToFile(outPut2, "C:/Users/rpa11/Desktop","stuna.doc");
//		} catch (Exception ex) {
//			ex.printStackTrace();
//		}
//	}

}
